import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  AnchorLink: () => import('../..\\components\\AnchorLink.vue' /* webpackChunkName: "components/anchor-link" */).then(c => wrapFunctional(c.default || c)),
  ArticleTop: () => import('../..\\components\\ArticleTop.vue' /* webpackChunkName: "components/article-top" */).then(c => wrapFunctional(c.default || c)),
  BackTop: () => import('../..\\components\\BackTop.vue' /* webpackChunkName: "components/back-top" */).then(c => wrapFunctional(c.default || c)),
  CategoryList: () => import('../..\\components\\CategoryList.vue' /* webpackChunkName: "components/category-list" */).then(c => wrapFunctional(c.default || c)),
  Footer: () => import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c)),
  Header: () => import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c)),
  HomeList: () => import('../..\\components\\HomeList.vue' /* webpackChunkName: "components/home-list" */).then(c => wrapFunctional(c.default || c)),
  PagInation: () => import('../..\\components\\PagInation.vue' /* webpackChunkName: "components/pag-ination" */).then(c => wrapFunctional(c.default || c)),
  Socials: () => import('../..\\components\\Socials.vue' /* webpackChunkName: "components/socials" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
