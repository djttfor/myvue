import { wrapFunctional } from './utils'

export { default as AnchorLink } from '../..\\components\\AnchorLink.vue'
export { default as ArticleTop } from '../..\\components\\ArticleTop.vue'
export { default as BackTop } from '../..\\components\\BackTop.vue'
export { default as CategoryList } from '../..\\components\\CategoryList.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as HomeList } from '../..\\components\\HomeList.vue'
export { default as PagInation } from '../..\\components\\PagInation.vue'
export { default as Socials } from '../..\\components\\Socials.vue'

export const LazyAnchorLink = import('../..\\components\\AnchorLink.vue' /* webpackChunkName: "components/anchor-link" */).then(c => wrapFunctional(c.default || c))
export const LazyArticleTop = import('../..\\components\\ArticleTop.vue' /* webpackChunkName: "components/article-top" */).then(c => wrapFunctional(c.default || c))
export const LazyBackTop = import('../..\\components\\BackTop.vue' /* webpackChunkName: "components/back-top" */).then(c => wrapFunctional(c.default || c))
export const LazyCategoryList = import('../..\\components\\CategoryList.vue' /* webpackChunkName: "components/category-list" */).then(c => wrapFunctional(c.default || c))
export const LazyFooter = import('../..\\components\\Footer.vue' /* webpackChunkName: "components/footer" */).then(c => wrapFunctional(c.default || c))
export const LazyHeader = import('../..\\components\\Header.vue' /* webpackChunkName: "components/header" */).then(c => wrapFunctional(c.default || c))
export const LazyHomeList = import('../..\\components\\HomeList.vue' /* webpackChunkName: "components/home-list" */).then(c => wrapFunctional(c.default || c))
export const LazyPagInation = import('../..\\components\\PagInation.vue' /* webpackChunkName: "components/pag-ination" */).then(c => wrapFunctional(c.default || c))
export const LazySocials = import('../..\\components\\Socials.vue' /* webpackChunkName: "components/socials" */).then(c => wrapFunctional(c.default || c))
