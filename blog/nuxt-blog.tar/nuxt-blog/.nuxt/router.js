import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _0166d037 = () => interopDefault(import('..\\pages\\archives.vue' /* webpackChunkName: "pages/archives" */))
const _b235e03c = () => interopDefault(import('..\\pages\\article\\index.vue' /* webpackChunkName: "pages/article/index" */))
const _937a2d84 = () => interopDefault(import('..\\pages\\category\\index.vue' /* webpackChunkName: "pages/category/index" */))
const _dbaed33a = () => interopDefault(import('..\\pages\\links.vue' /* webpackChunkName: "pages/links" */))
const _5d2d2258 = () => interopDefault(import('..\\pages\\search\\index.vue' /* webpackChunkName: "pages/search/index" */))
const _6811477a = () => interopDefault(import('..\\pages\\tags\\index.vue' /* webpackChunkName: "pages/tags/index" */))
const _724cba6c = () => interopDefault(import('..\\pages\\article\\_id.vue' /* webpackChunkName: "pages/article/_id" */))
const _03562326 = () => interopDefault(import('..\\pages\\category\\_id.vue' /* webpackChunkName: "pages/category/_id" */))
const _2d44de8b = () => interopDefault(import('..\\pages\\search\\_keywords.vue' /* webpackChunkName: "pages/search/_keywords" */))
const _2aab214f = () => interopDefault(import('..\\pages\\tags\\_id\\_name.vue' /* webpackChunkName: "pages/tags/_id/_name" */))
const _7c678a08 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/archives",
    component: _0166d037,
    name: "archives"
  }, {
    path: "/article",
    component: _b235e03c,
    name: "article"
  }, {
    path: "/category",
    component: _937a2d84,
    name: "category"
  }, {
    path: "/links",
    component: _dbaed33a,
    name: "links"
  }, {
    path: "/search",
    component: _5d2d2258,
    name: "search"
  }, {
    path: "/tags",
    component: _6811477a,
    name: "tags"
  }, {
    path: "/article/:id",
    component: _724cba6c,
    name: "article-id"
  }, {
    path: "/category/:id",
    component: _03562326,
    name: "category-id"
  }, {
    path: "/search/:keywords",
    component: _2d44de8b,
    name: "search-keywords"
  }, {
    path: "/tags/:id/:name?",
    component: _2aab214f,
    name: "tags-id-name"
  }, {
    path: "/",
    component: _7c678a08,
    name: "index"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
